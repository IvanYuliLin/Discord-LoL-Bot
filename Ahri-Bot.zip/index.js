// main code
const Discord = require("discord.js");
const client = new Discord.Client({intents: ["GUILDS", "GUILD_MESSAGES"]});
const riotKey = 'api_key='+process.env.lol_api;
const keepAlive = require("./server")
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

async function summonerid(msg) {
  const link = 'https://na1.api.riotgames.com/lol/summoner/v4/summoners/by-name/drunkcereal?'+riotKey
  const response = await fetch(link);
  let data = await response.json();
  let embed = new Discord.MessageEmbed()
  .setTitle("DrunkCereal's Summoner Info")
  .setFooter("Summoner name: " + data.name)
  .setColor("RANDOM")
  msg.channel.send({embeds:[embed]})
}

client.on("ready", () => {
  console.log('Project Start!')
})

client.on("messageCreate", msg => {
  if (msg.content === "!tips") {
    msg.channel.send('Just win!')
  }
  if (msg.content === "!opgg") {
    let embed = new Discord.MessageEmbed()
    .setTitle("DrunkCereal's opgg")
    .setURL("https://na.op.gg/summoners/na/DrunkCereal")
    .setColor("RANDOM")
    msg.channel.send({embeds:[embed]})
  }
  if (msg.content === "!summoner") {
    summonerid(msg)
  }
})

keepAlive()
client.login(process.env.token);