// main code
const Discord = require("discord.js");
const client = new Discord.Client({intents: ["GUILDS", "GUILD_MESSAGES"]});
const riotKey = '?api_key='+process.env.lol_api;
const keepAlive = require("./server")
const request = require("request");


// summoner info
async function printsummonerid(msg) {
  const sumName = msg.content.substring(msg.content.indexOf(' ')+1)
  const link = 'https://na1.api.riotgames.com/lol/summoner/v4/summoners/by-name/'+sumName+riotKey
  
  request(link, function(error, response, body) {
    // doesn't exist
    if (response.statusCode == 404) {
      let embed = new Discord.MessageEmbed()
      .setTitle("Summoner doesn't exist")
      .setDescription("Sad Ahri noises :(")
      .setColor("RED")
      msg.channel.send({embeds:[embed]})
    // does exist
    } else {
      var data = JSON.parse(body)
      var name = data.name
      var lvl = data.summonerLevel
      var iconid = String(data.profileIconId)
      var icon_url = "http://ddragon.leagueoflegends.com/cdn/12.9.1/img/profileicon/"+iconid+".png"
  
      // get more info
      var id = data.id
      const link2 = 'https://na1.api.riotgames.com/lol/league/v4/entries/by-summoner/'+id+riotKey
      request(link2, function(error2, response2, body2) {
        var data2 = JSON.parse(body2)
        if (data2 == undefined || data2.length == 0) {
          let embed = new Discord.MessageEmbed()
          .setTitle("Account exists and doesn't exist at the same time")
          .setDescription("Confused Ahri noises HAs9%$@4dH*23h(???")
          .setColor("RED")
          msg.channel.send({embeds:[embed]})
        } else {
          var tier = data2[0].tier
          var rank = data2[0].rank
          var points = data2[0].leaguePoints
          var wins = data2[0].wins
          var losses = data2[0].losses
    
          // embed stuff
          let embed = new Discord.MessageEmbed()
          .setTitle(data.name+"'s Summoner Info")
          .setColor("BLURPLE")
          .setThumbnail(icon_url)
          .addFields(
            {name: "Name", value: name, inline: true},
            {name: "Level", value: String(lvl)}
          )
          .addFields(
            {name: "Tier", value: String(tier), inline: true},
            {name: "Rank", value: String(rank), inline: true},
            {name: "LP", value: String(points), inline: true},
          )
          .addFields(
            {name: "Wins", value: String(wins), inline: true},
            {name: "Losses", value: String(losses), inline: true}
          )
          msg.channel.send({embeds:[embed]})
        }
      })
    }
  })
}

// print live match
async function getMatch(msg) {
  const sumName = msg.content.substring(msg.content.indexOf(' ')+1)
  const link1 = 'https://na1.api.riotgames.com/lol/summoner/v4/summoners/by-name/'+sumName+riotKey
  
  request(link1, function(error, response, body) {
    // doesn't exist
    if (response.statusCode == 404) {
      let embed = new Discord.MessageEmbed()
      .setTitle("Summoner doesn't exist")
      .setDescription("Sad Ahri noises :(")
      .setColor("RED")
      msg.channel.send({embeds:[embed]})
    // does exist
    } else {
      var data = JSON.parse(body)
      var id = data.id
      const link2 = 'https://na1.api.riotgames.com/lol/spectator/v4/active-games/by-summoner/'+id+riotKey
      request(link2, function(error2, response2, body2) {
        // if summoner not in match
        if (response2.statusCode == 404) {
          let embed = new Discord.MessageEmbed()
          .setTitle(data.name+" is not in a match!")
          .setDescription("Sad Ahri noises :(")
          .setColor("RED")
          msg.channel.send({embeds:[embed]})
        // if summoner is in a match
        } else {
          var data2 = JSON.parse(body2)
          var gamemode = data2.gameMode
          var gamelength = data2.gameLength
          var gametype = data2.gameType
          // main game info embed
          let embed = new Discord.MessageEmbed()
          .setTitle(data.name+" is in a match!")
          .addField("Game Mode", gamemode)
          .addField("Game Type", gametype)
          .addField("Game Time Elapsed (Seconds)", String(gamelength))
          .setColor("DARK_BLUE")
          msg.channel.send({embeds:[embed]})

          // players embed
          var players = data2.participants
          var c = ["", "", "", "", "", "", "", "", "", ""]
          request("http://ddragon.leagueoflegends.com/cdn/12.9.1/data/en_US/champion.json", function(error3, response3, body3) {
          var list = JSON.parse(body3)
          var champions = list.data

          for (var i = 0; i < 10; i++) {
            for (var j in champions) {
              if (champions[j].key == players[i].championId) {
                c[i] = champions[j].id
              }
            }
          }

          let embed2 = new Discord.MessageEmbed()
          .setTitle("Blue Side Players")
          .setColor("BLUE")
          .addFields(
            {name: players[0].summonerName, value: "Champion: "+c[0]},
            {name: players[1].summonerName, value: "Champion: "+c[1]},
            {name: players[2].summonerName, value: "Champion: "+c[2]},
            {name: players[3].summonerName, value: "Champion: "+c[3]},
            {name: players[4].summonerName, value: "Champion: "+c[4]}
          )

          let embed3 = new Discord.MessageEmbed()
          .setTitle("Red Side Players")
          .addFields(
            {name: players[5].summonerName, value: "Champion: "+c[5]},
            {name: players[6].summonerName, value: "Champion: "+c[6]},
            {name: players[7].summonerName, value: "Champion: "+c[7]},
            {name: players[8].summonerName, value: "Champion: "+c[8]},
            {name: players[9].summonerName, value: "Champion: "+c[9]}
          )
          .setColor("RED")

          msg.channel.send({embeds:[embed2]})
          msg.channel.send({embeds:[embed3]})
         })
        }
      })
    }
  })
  
}

// ahri help
async function ahriHelp(msg) {
  let embed = new Discord.MessageEmbed()
  .setTitle("Ahri Bot Commands")
  .addFields(
    {name: "Find summoner info", value: "!summoner {name}"},
    {name: "Find current match info", value: "!match {name}"}
  )
  .setColor("LUMINOUS_VIVID_PINK")
  msg.channel.send({embeds:[embed]})
}

client.on("ready", () => {
  client.user.setActivity('!ahri help')
  console.log('Project Start!')
})

client.on("messageCreate", msg => {
  if (msg.content.startsWith("!summoner")) {
    printsummonerid(msg)
  }
  if (msg.content.startsWith("!match")) {
    getMatch(msg)
  }
  if (msg.content == "!ahri help") {
    ahriHelp(msg)
  }
})

keepAlive()
client.login(process.env.token);